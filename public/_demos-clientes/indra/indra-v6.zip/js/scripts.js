function onLoadPage(){
  jQuery("body").addClass("out");

  setTimeout(function(){
    jQuery("body").removeClass("out").removeClass("loading");
  }, 1000);
}

function playVideo(){
  "use strict";
  var video = $("#videoContainer iframe").attr('src');

  $("#videoContainer").toggleClass("d-none").addClass("show");
  $("#videoContainer iframe").attr('src', `${video}&autoplay=1`);
  //$("#videoContainer").html('<iframe width="100%" height="100%" src="https://www.youtube-nocookie.com/embed/SkcRebG58K8?controls=0&autoplay=1&loop=1&rel=0&wmode=transparent" title="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
}

jQuery(document).ready(function(){
  onLoadPage();

  /*$(".video-layer").on("click", function(){
    playVideo();
  });*/

  /*var player = videojs('video-js', {
    autoplay: 'muted'
  });*/

  /* ---------------------------------------------------------------------------------------------------------*/

  $(".b-slider .slick-slider").on('beforeChange', function(event, slick, currentSlide, nextSlide){
    var p = Math.floor(((nextSlide+1) / slick.slideCount) * 100);
    $(".los-desafios .b-slider .progress-bar .bar").css( "width", p+"%");
  });
  $(".b-slider .slick-slider").on('init', function(event, slick){
    var p = Math.floor(((slick.currentSlide+1) / slick.slideCount) * 100);
    $(".los-desafios .b-slider .progress-bar .bar").css( "width", p+"%");
  });

  //$(".los-desafios .b-slider .progress-bar .bar").css({ width: "0px" });

  var b_slider = $(".b-slider .slick-slider").slick({
    arrows: true,
    autoplay: false,
    autoplaySpeed: 3000,
    cssEase: 'ease',
    dots: false,
    draggable: true,
    easing: 'easing',
    infinite: true,
    lazyLoad: 'ondemand',
    slidesToShow: 3,
    slidesToScroll: 1,
    speed: 600,
    waitForAnimate: true,
    dragging: true,
    variableWidth: false,
    responsive: [{
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
      }
    }],
  });

  /* ---------------------------------------------------------------------------------------------------------*/

  jQuery(window).scroll(function() {
    stateScrollTop();
  });

  stateScrollTop();

  /* ---------------------------------------------------------------------------------------------------------*/

  /*$(window).resize(function() {
    $(".navbar").removeClass("open");
    $(".navbar .menu-content .navbar-collapse").removeClass("show");
    $(".navbar .menu-content .navbar-toggler").attr("aria-expanded", "false");
    $(".navbar .menu-content .navbar-toggler").removeClass("collapsed").addClass("collapsed");
    $("body").removeClass("open-menu");

    if ($(window).width() <= 991) {
      $(".modal").removeClass("show");
      $(".modal").attr("aria-modal", "false");
      $("body").removeClass("modal-open");
      $(".modal-backdrop").remove();
    }
  });*/

  /* ---------------------------------------------------------------------------------------------------------*/

  //let isMobile = window.matchMedia("only screen and (max-width: 480px)").matches;
  //if (!isMobile) {
    AOS.init({
      // Global settings:
      disable: false, // accepts following values: 'phone', 'tablet', 'mobile', boolean, expression or function
      startEvent: 'DOMContentLoaded', // name of the event dispatched on the document, that AOS should initialize on
      initClassName: 'aos-init', // class applied after initialization
      animatedClassName: 'aos-animate', // class applied on animation
      useClassNames: false, // if true, will add content of `data-aos` as classes on scroll
      disableMutationObserver: false, // disables automatic mutations' detections (advanced)
      debounceDelay: 50, // the delay on debounce used while resizing window (advanced)
      throttleDelay: 99, // the delay on throttle used while scrolling the page (advanced)

      // Settings that can be overridden on per-element basis, by `data-aos-*` attributes:
      offset: 0, // offset (in px) from the original trigger point
      delay: 50, // values from 0 to 3000, with step 50ms
      duration: 800, // values from 0 to 3000, with step 50ms
      easing: 'ease', // default easing for AOS animations
      once: false, // whether animation should happen only once - while scrolling down
      mirror: true, // whether elements should animate out while scrolling past them
      //anchorPlacement: 'top-bottom', // defines which position of the element regarding to window should trigger the animation
    });
  //}

  /*if($("#map").length){
    includeJs("https://maps.googleapis.com/maps/api/js?key=AIzaSyBNAkZFUwm1V7Jcd4d0B5sw570K1SrSWXc&callback=initMap");
  }*/

});

/*function includeJs(jsFilePath) {
  var js = document.createElement("script");
  js.type = "text/javascript";
  js.src = jsFilePath;
  document.body.appendChild(js);
}*/

/*function initMap() {
  if(!document.getElementById('map')){ return false; }

  var styles = [{
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [{
        "color": "#e9e9e9"
      }, {
        "lightness": 17
      }
    ]
  }, {
    "featureType": "landscape",
    "elementType": "geometry",
    "stylers": [{
        "color": "#f5f5f5"
      }, {
        "lightness": 20
      }
    ]
  }, {
    "featureType": "road.highway",
    "elementType": "geometry.fill",
    "stylers": [{
        "color": "#ffffff"
      }, {
        "lightness": 17
      }
    ]
  }, {
    "featureType": "road.highway",
    "elementType": "geometry.stroke",
    "stylers": [{
        "color": "#ffffff"
      }, {
        "lightness": 29
      }, {
        "weight": 0.2
      }
    ]
  }, {
    "featureType": "road.arterial",
    "elementType": "geometry",
    "stylers": [{
        "color": "#ffffff"
      }, {
        "lightness": 18
      }
    ]
  }, {
    "featureType": "road.local",
    "elementType": "geometry",
    "stylers": [{
        "color": "#ffffff"
      }, {
        "lightness": 16
      }
    ]
  }, {
    "featureType": "poi",
    "elementType": "geometry",
    "stylers": [{
        "color": "#f5f5f5"
      }, {
        "lightness": 21
      }
    ]
  }, {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [{
        "color": "#dedede"
      }, {
        "lightness": 21
      }
    ]
  }, {
    "elementType": "labels.text.stroke",
    "stylers": [{
        "visibility": "on"
      }, {
        "color": "#ffffff"
      }, {
        "lightness": 16
      }
    ]
  }, {
    "elementType": "labels.text.fill",
    "stylers": [{
        "saturation": 36
      }, {
        "color": "#333333"
      }, {
        "lightness": 40
      }
    ]
  }, {
    "elementType": "labels.icon",
    "stylers": [{
      "visibility": "off"
    }]
  }, {
    "featureType": "transit",
    "elementType": "geometry",
    "stylers": [{
      "color": "#f2f2f2"
    }, {
      "lightness": 19
    }]
  }, {
    "featureType": "administrative",
    "elementType": "geometry.fill",
    "stylers": [{
      "color": "#fefefe"
    }, {
      "lightness": 20
    }]
  }, {
    "featureType": "administrative",
    "elementType": "geometry.stroke",
    "stylers": [{
      "color": "#fefefe"
    }, {
      "lightness": 17
    }, {
      "weight": 1.2
    }]
  }];

  map = new google.maps.Map(
    document.getElementById("map"), {
      center: { lat: ubicaciones[0][1], lng: ubicaciones[0][2] },
      zoom: 13,
      scrollwheel:!1
    }
  );

  map.setOptions({styles: styles, mapTypeControl: false, streetViewControl: false, fullscreenControl: false, scaleControl: false, disableDefaultUI: false });

  setMarkers(map);
}*/

/*const ubicaciones = [
  ["", 41.3781008, 2.1755412, 0, '']
];

var map;
var marker = [];
var infowindow;
var content = [];*/

/*function setMarkers(map) {
  var images = [{
    url: "images/logo-gmap.png",
    size: new google.maps.Size(93, 111),
    origin: new google.maps.Point(0, 0),
    anchor: new google.maps.Point(46, 111),
  }];

  var infowindowContenido = [{
    icon: "",
    titulo: "",
    texto: ""
  }];

  infowindow = new google.maps.InfoWindow();

  var i = 0;
  marker[i] = new google.maps.Marker({
    position: { lat: ubicaciones[i][1], lng: ubicaciones[i][2] },
    map,
    icon: images[i]
  });

  for (var i = 0; i < ubicaciones.length; i++) {
    var content_ = "<div class='marker-holder'>";
        content_ += "<div class='titulo'>"+infowindowContenido[i].titulo+"</div>";
        content_ += "<div class='texto'>"+infowindowContenido[i].texto+"</div>";
        content_ += "</div>";
    content[i] = content_;

    marker[i] = new google.maps.Marker({
      position: { lat: ubicaciones[i][1], lng: ubicaciones[i][2] },
      map,
      icon: images[i]
    });

    marker[i].setVisible(false);
  }

  infowindow.setContent(content[0]);
  infowindow.open(map, marker[0]);
  marker[0].setVisible(true);
}*/

/* ------------------------------------------------------------------------------------------ */

var lastScrollTop = 0;

function stateScrollTop(){
  var distance = jQuery('.navbar').outerHeight();

  if (jQuery(this).scrollTop() >= 1) {
    jQuery('.navbar').addClass("bg");
  } else {
    jQuery('.navbar').removeClass("bg");
  }

  /*if (jQuery(this).scrollTop() >= distance) {
    var st = $(this).scrollTop();
    if (st > lastScrollTop){
      jQuery('.navbar').css({ top: -(jQuery(".navbar").outerHeight())+"px" });
    } else {
      jQuery('.navbar').css({ top: 0 });
    }
    lastScrollTop = st;
  } else {
  }*/
}
